package com.taxcalculator.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

@Service
public class CongestionTaxCalculator {

	private static Map<String, Integer> tollFreeVehicles = new HashMap<>();

	static {
		tollFreeVehicles.put("Motorcycle", 0);
		tollFreeVehicles.put("Busses", 1);
		tollFreeVehicles.put("Emergency", 2);
		tollFreeVehicles.put("Diplomat", 3);
		tollFreeVehicles.put("Foreign", 4);
		tollFreeVehicles.put("Military", 5);

	}

	public Map<LocalDate, Integer> calculateTax(String vehicle, List<String> dateList) {
		
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
		
		
		 List<LocalDateTime> dates = dateList.stream().map(date -> LocalDateTime.parse(date, formatter)).sorted().collect(Collectors.toList());

		Map<LocalDate, List<LocalDateTime>> date = dates.stream().collect(Collectors.groupingBy(time -> {
			
			   return time.toLocalDate();
			}));
			
		Map<LocalDate,Integer> taxAmount = new HashMap<>();
		
		date.entrySet().forEach(entry -> {
			taxAmount.put(entry.getKey(),getTax(vehicle, entry.getValue()));
			
		});
		
		return taxAmount;
	}

	public Integer getTax(String vehicle, List<LocalDateTime> dates) {
		int totalFee = 0;
		int maxPay = 0;
		LocalDateTime intervalstart = dates.get(0);

		for (int i = 0; i < dates.size(); i++) {
			LocalDateTime date = dates.get(i);
			int nextFee = GetTollFee(date, vehicle);
			if (totalFee >= 60)
				break;
			if (totalFee != 0) {
				
				long diffInMillies = dates.get(i).toEpochSecond(ZoneOffset.UTC)
						- intervalstart.toEpochSecond(ZoneOffset.UTC);
				long minutes = diffInMillies / 60;
				
				if (minutes <= 60) {
					if (nextFee > maxPay) {

						totalFee -= maxPay;
						totalFee += nextFee;
						maxPay = nextFee;

					}
				} else {
					intervalstart = dates.get(i);
					totalFee += nextFee;
					maxPay = nextFee;
				}

			} else {
				totalFee += nextFee;
				maxPay = nextFee;
			}

		}

		if (totalFee >= 60)
			totalFee = 60;
		return totalFee;
	}

	private boolean IsTollFreeVehicle(String vehicle) {
		if (vehicle == null)
			return false;
		return tollFreeVehicles.containsKey(vehicle);
	}

	public int GetTollFee(LocalDateTime date, String vehicle) {
		if (IsTollFreeDate(date) || IsTollFreeVehicle(vehicle))
			return 0;

		int hour = date.getHour();
		int minute = date.getMinute();

		if (hour == 6 && minute >= 0 && minute <= 29)
			return 8;
		else if (hour == 6 && minute >= 30 && minute <= 59)
			return 13;
		else if (hour == 7 && minute >= 0 && minute <= 59)
			return 18;
		else if (hour == 8 && minute >= 0 && minute <= 29)
			return 13;
		else if ((hour >= 8 && hour >= 30) ||( hour >= 9 && hour <= 14 && minute <=59))
			return 8;
		else if (hour == 15 && minute >= 0 && minute <= 29)
			return 13;
		else if (hour == 15 && minute >= 0 || hour == 16 && minute <= 59)
			return 18;
		else if (hour == 17 && minute >= 0 && minute <= 59)
			return 13;
		else if (hour == 18 && minute >= 0 && minute <= 29)
			return 8;
		else
			return 0;
	}

	private Boolean IsTollFreeDate(LocalDateTime date) {
		int year = date.getYear();
		int month = date.getMonthValue() + 1;
		int day = date.getDayOfWeek().getValue() + 1;
		int dayOfMonth = date.getDayOfMonth();

		if (day == Calendar.SATURDAY || day == Calendar.SUNDAY)
			return true;

		if (year == 2013) {
			if ((month == 1 && dayOfMonth == 1) || (month == 3 && (dayOfMonth == 28 || dayOfMonth == 29))
					|| (month == 4 && (dayOfMonth == 1 || dayOfMonth == 30))
					|| (month == 5 && (dayOfMonth == 1 || dayOfMonth == 8 || dayOfMonth == 9))
					|| (month == 6 && (dayOfMonth == 5 || dayOfMonth == 6 || dayOfMonth == 21)) || (month == 7)
					|| (month == 11 && dayOfMonth == 1) || (month == 12
							&& (dayOfMonth == 24 || dayOfMonth == 25 || dayOfMonth == 26 || dayOfMonth == 31))) {
				return true;
			}
		}
		return false;
	}
}
