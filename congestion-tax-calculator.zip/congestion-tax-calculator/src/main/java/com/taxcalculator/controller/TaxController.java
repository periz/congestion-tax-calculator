package com.taxcalculator.controller;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.taxcalculator.service.CongestionTaxCalculator;

@RestController
public class TaxController {

@Autowired
private CongestionTaxCalculator taxCalculator;

@PostMapping("/calculate/tax/{vehicletype}")
public ResponseEntity calculateTax(@PathVariable String vehicletype, @RequestBody List<String> dateList){
	
	Map<LocalDate, Integer> taxAmount = taxCalculator.calculateTax(vehicletype, dateList);
	
	return ResponseEntity.ok(taxAmount);
}

	
	
}
