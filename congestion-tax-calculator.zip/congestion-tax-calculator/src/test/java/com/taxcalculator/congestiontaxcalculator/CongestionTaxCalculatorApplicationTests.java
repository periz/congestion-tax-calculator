package com.taxcalculator.congestiontaxcalculator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CongestionTaxCalculatorApplicationTests {

	@Test
	void contextLoads() {
	}

}
