
After starting the application hit http://localhost:8080/swagger-ui.html#/tax-controller to test the tax calculator
 
Sample Input :
 
	http://localhost:8080/calculate/tax/{vehicletype}  ie :http://localhost:8080/calculate/tax/car
 
 Request Body :
 
	[
		"2013-01-14 21:00:00",
		"2013-01-15 21:00:00",
		"2013-02-07 06:23:27",
		"2013-02-07 15:27:00"
	]